# ImCore 即时通讯
## 简介
利用 webSocket 协议实现简易、高性能、集群即时通讯组件，支持点对点通讯、群聊通讯、上线下线事件消息等众多实用性功能。

## 开源地址
[https://github.com/2881099/im](https://github.com/2881099/im)

## 示例
[https://github.com/luoyunchong/dotnetcore-examples/tree/master/dotnet-core-im](https://github.com/luoyunchong/dotnetcore-examples/tree/master/dotnet-core-im)

## 演示效果

![https://ae01.alicdn.com/kf/Hf8b31f05dbb94f8da565fce29f78aa78Y.png](https://ae01.alicdn.com/kf/Hf8b31f05dbb94f8da565fce29f78aa78Y.png)

