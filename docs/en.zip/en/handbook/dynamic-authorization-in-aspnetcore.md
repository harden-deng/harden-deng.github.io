# 认证与授权

主要就**基于权限的授权**的实现进行研究，实现方法级别的权限验证。

- [https://www.cnblogs.com/RainingNight/p/dynamic-authorization-in-asp-net-core.html](https://www.cnblogs.com/RainingNight/p/dynamic-authorization-in-asp-net-core.html)

## 认证鉴权相关

IdentityServer4

- [ASP.NET Core WebAPI JWT Bearer 认证失败返回自定义数据 Json](https://blog.csdn.net/jasonsong2008/article/details/89226705)
- [IdentityServer4 中文文档与实战](https://www.cnblogs.com/stulzq/p/8119928.html)

## JWT

json web token
