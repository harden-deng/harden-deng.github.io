# Attachment

![](images/icon_Attachment.png)

## Features

- [X] Basic Usage

### Basic Usage

Basic function :upload files.

## UI Preview

### Design Time

![](images/Attachment_Features_pic1.png)

### Run Time

![](images/Attachment_Features_pic2.png)

## Key Attribute for component

| Attribute Name  | Attribute Description                                                                                                     | Additional Info                                           |
| :-------------- | :------------------------------------------------------------------------------------------------------------------------ | :-------------------------------------------------------- |
| Source Key      | Component ID for the data source                                                                                          | Config when the input value is comes from other component |