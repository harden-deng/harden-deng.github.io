# Template Center

Show all templates and manage template.

![](images/Templates_Features_Pic4.png)

## Features

- [X] Display Report Template List (draft & released)
- [X] Delete
- [X] Enable/Disable
- [X] Version History
- [X] Copy and Create
- [X] Data Mapping
- [X] Authorization
- [X] Divider Maintenance

## Create a new template

1.Click  "**New Template**" button.

![](images/Templates_Features_Pic1.png)

2.Fill in tempate infomation.

![](images/Templates_Features_Pic2.png)

3.Desinge template and save/publish.

![img](images/Templates_Features_Pic3.png)

## Tempate history

1.Click "..." button on target tempate, and click  "Version History".

![](images/Templates_Features_Pic4.png)

2.Click "ENE" link on target version.

![](images/Templates_Features_Pic5.png)

3.Show the history template designe model.

![](images/Templates_Features_Pic6.png)
