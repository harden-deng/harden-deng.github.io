# IdentityServer4

## 写的一些IdentityServer4的示例

IdentityServer4 实现单点登录授权token验证

## 源码
代码托管在GitHub上 [https://github.com/luoyunchong/dotnetcore-examples/tree/master/aspnetcore-identityserver4](https://github.com/luoyunchong/dotnetcore-examples/tree/master/aspnetcore-identityserver4)


## 参考 
- [.NET Core微服务之基于IdentityServer建立授权与验证服务](https://www.cnblogs.com/edisonchou/p/identityserver4_foundation_and_quickstart_01.html)
